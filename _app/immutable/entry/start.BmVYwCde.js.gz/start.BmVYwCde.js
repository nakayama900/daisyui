import{a as t}from"../chunks/entry.BTZh6AU_.js";export{t as start};
