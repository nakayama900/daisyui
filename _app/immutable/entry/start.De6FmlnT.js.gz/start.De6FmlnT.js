import{a as t}from"../chunks/entry.D6ykt7yw.js";export{t as start};
